create PACKAGE Calendario AS

  PROCEDURE EmparejarEmpleados_21;

  PROCEDURE ListarParejas_21 (out_cursor OUT SYS_REFCURSOR);

PROCEDURE ListarMisParejas_21 (
  p_apellido IN Empleados_Equipos.APELLIDO%TYPE,
  out_cursor OUT SYS_REFCURSOR
);

END Calendario;
/

