create PROCEDURE informe_equipos_temporada 
    (p_cod_temporada IN temporadas.cod_temporada%type,
    out_cursor OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN out_cursor FOR
        SELECT e.cod_equipo AS "Código del equipo",
       e.nombre AS "Nombre del equipo",
       e.presupuesto AS "Presupuesto del equipo",
       contar_numero_jugadores_por_equipo(e.cod_equipo, p_cod_temporada) AS "Número de jugadores",
       p.cod_miembro AS cod_presidente,
       p.nombre || ' ' || p.apellido AS nombre_presidente,
       p.fecha_entrada AS "Presidente desde",
       en.cod_miembro AS cod_entrenador,
       en.nombre || ' ' || en.apellido AS nombre_entrenador,
       s.cod_miembro AS cod_staff,
       s.nombre || ' ' || s.apellido AS nombre_staff
    FROM equipos e
    JOIN registros_equipos ep ON e.cod_equipo = ep.cod_equipo AND ep.cod_temporada = p_cod_temporada
    LEFT JOIN presidentes_equipos p ON e.cod_equipo = p.cod_equipo
    LEFT JOIN entrenadores_equipos en ON e.cod_equipo = en.cod_equipo
    LEFT JOIN staffs_equipos s ON e.cod_equipo = s.cod_equipo;

END informe_equipos_temporada;
/

