create PROCEDURE informe_jugador_ultima_temporada
    (p_cod_temporada IN temporadas.cod_temporada%type,
    out_cursor OUT SYS_REFCURSOR)
as
    v_cod_temporada temporadas.cod_temporada%type;
begin

    select max(cod_temporada) into v_cod_temporada
    from temporadas
    where ano = (select max(ano) from temporadas);

    open out_cursor for
        select j.cod_jugador, j.nombre, j.apellido, cj.cod_contrato, cj.clausula, cj.salario, cj.cod_equipo, e.nombre
        from jugadores j, draft d, contratos_equipo_jugador cj, equipos e
        where j.cod_jugador = d.cod_jugador
        and j.cod_jugador = cj.cod_jugador
        and cj.cod_equipo = e.cod_equipo
        and EXTRACT(YEAR FROM fecha_inicio) = (select ano from temporadas where cod_temporada = p_cod_temporada);

end informe_jugador_ultima_temporada;
/

