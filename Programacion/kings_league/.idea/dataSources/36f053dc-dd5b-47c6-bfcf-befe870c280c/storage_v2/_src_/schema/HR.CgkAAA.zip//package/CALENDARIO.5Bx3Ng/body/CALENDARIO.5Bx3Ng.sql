create PACKAGE BODY Calendario AS
--------------------------------------------------------------------------------
PROCEDURE EmparejarEmpleados_21 AS
  numEmpleados NUMBER;
  numEmparejamientos NUMBER;
  fecha_inicio DATE := SYSDATE;
  fecha DATE := fecha_inicio;
  fecha_fin DATE;
  numeroJornada NUMBER := -1;
  -- Define a user-defined type as a table of two emp_no data types
    TYPE int_array IS RECORD (
    emp_no1 empleados_equipos.emp_no%type,
    emp_no2 empleados_equipos.emp_no%type
  );

  TYPE int_array_table IS TABLE OF int_array INDEX BY PLS_INTEGER;
  my_array int_array_table;

  numDeFilas NUMBER;
  i PLS_INTEGER := 1;

  jornadaAsignada boolean := false;
BEGIN
  SELECT COUNT(*) INTO numEmpleados FROM Empleados_Equipos;
  fecha_fin := sysdate + (numEmpleados - 2);

  IF MOD(numEmpleados, 2) != 0 THEN
    dbms_output.put_line('No se pueden emparejar empleados porque el número total de empleados es impar.');
  ELSE
    numEmparejamientos := numEmpleados / 2;

   FOR emp_rec IN (SELECT emp_no FROM empleados_equipos)
   LOOP
    FOR emp_rec2 in (SELECT emp_no FROM empleados_equipos WHERE emp_no > emp_rec.emp_no)
    LOOP
        my_array(i).emp_no1 := emp_rec.emp_no; -- set first element values
        my_array(i).emp_no2 := emp_rec2.emp_no;
        i := i + 1;
    END LOOP;
   END LOOP;


   FOR i IN my_array.FIRST .. my_array.LAST 
   LOOP
        jornadaAsignada := false;
        while NOT jornadaAsignada 
        loop
            select count(*) into numeroJornada from calendario_parejas 
            where fecha_jornada = fecha 
            and ((id_empleado1 = my_array(i).emp_no1 or id_empleado2 = my_array(i).emp_no1) 
            or (id_empleado1 = my_array(i).emp_no2 or id_empleado2 = my_array(i).emp_no2));
            if numeroJornada = 0
            then
                insert into calendario_parejas(id_empleado1, id_empleado2, fecha_jornada) values(my_array(i).emp_no1, my_array(i).emp_no2, fecha);
                jornadaAsignada := true;
            end if;
            fecha := fecha + 1;
        end loop;
        fecha := sysdate;
   END LOOP;

  END IF;


END;

--------------------------------------------------------------------------------
PROCEDURE ListarParejas_21 (out_cursor OUT SYS_REFCURSOR)
AS
BEGIN
  OPEN out_cursor FOR
    SELECT e1.EMP_NO AS empleado1, e1.APELLIDO AS apellido1,
           e2.EMP_NO AS empleado2, e2.APELLIDO AS apellido2,
           TO_CHAR(cp.fecha_jornada, 'DD/MM/YYYY') AS fecha_jornada
    FROM Calendario_Parejas cp,
    Empleados_Equipos e1, Empleados_Equipos e2
    WHERE cp.id_empleado1 = e1.EMP_NO(+)
    AND cp.id_empleado2 = e2.EMP_NO(+)
    ORDER BY e1.EMP_NO;
END;

--------------------------------------------------------------------------------
PROCEDURE ListarMisParejas_21 (
  p_apellido IN Empleados_Equipos.APELLIDO%TYPE,
  out_cursor OUT SYS_REFCURSOR
) AS
BEGIN
  OPEN out_cursor FOR
    SELECT cp.id, e1.APELLIDO AS apellido1, e2.APELLIDO AS apellido2,
           TO_CHAR(cp.fecha_jornada, 'DD/MM/YYYY') AS fecha_jornada
    FROM Calendario_Parejas cp, Empleados_Equipos e1, Empleados_Equipos e2
    WHERE cp.id_empleado1 = e1.EMP_NO(+)
      AND cp.id_empleado2 = e2.EMP_NO(+)
      AND (e1.APELLIDO = p_apellido OR e2.APELLIDO = p_apellido)
    ORDER BY cp.fecha_jornada;
END;
------------------------------------------------------------------------
END Calendario;
/

