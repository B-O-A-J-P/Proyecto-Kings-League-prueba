create FUNCTION contar_numero_jugadores_por_equipo
    (p_cod_equipo IN hr.equipos.cod_equipo%type,
    p_cod_temporada IN hr.temporadas.cod_temporada%type)
    RETURN NUMBER
is
    v_num_jugadores NUMBER;
begin

    SELECT count(*) into v_num_jugadores
    FROM temporadas t
    JOIN equipos_participantes ep ON t.cod_temporada = ep.cod_temporada
    JOIN equipos e ON ep.cod_equipo = e.cod_equipo AND ep.cod_equipo = p_cod_equipo
    JOIN contratos_equipo_jugador cj ON e.cod_equipo = cj.cod_equipo AND EXTRACT(YEAR FROM cj.fecha_inicio) = t.ano
    JOIN draft d ON cj.cod_jugador = d.cod_jugador AND ep.cod_temporada = d.cod_temporada
    WHERE t.cod_temporada = p_cod_temporada;


    return v_num_jugadores;

end contar_numero_jugadores_por_equipo;
/

