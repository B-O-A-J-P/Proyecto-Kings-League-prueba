create trigger TRIGER_JORNADAS_FEC
    before insert or update
    on JORNADAS
    for each row
BEGIN
  IF :NEW.fecha < (SYSDATE) THEN
    RAISE_APPLICATION_ERROR(-20001, 'La fecha tiene que ser igual o superior a la fecha actual.');
  END IF;
END;

/

