create trigger TRIGER_SPLITS_FEC_INI
    before insert or update
    on SPLITS
    for each row
BEGIN
  IF :NEW.fecha_inicio < (SYSDATE) THEN
    RAISE_APPLICATION_ERROR(-20001, 'La fecha tiene que ser igual o superior a la fecha actual');
  END IF;
END;

/

