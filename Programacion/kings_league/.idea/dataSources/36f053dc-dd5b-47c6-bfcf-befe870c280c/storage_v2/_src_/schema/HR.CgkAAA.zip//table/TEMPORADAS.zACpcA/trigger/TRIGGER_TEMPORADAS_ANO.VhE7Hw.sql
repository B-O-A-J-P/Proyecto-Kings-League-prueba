create trigger TRIGGER_TEMPORADAS_ANO
    before insert or update
    on TEMPORADAS
    for each row
BEGIN
  IF :NEW.ano < EXTRACT(YEAR FROM TRUNC(SYSDATE)) THEN
    RAISE_APPLICATION_ERROR(-20001, 'El año tiene que ser igual o superior al año actual.');
  END IF;
END;
/

